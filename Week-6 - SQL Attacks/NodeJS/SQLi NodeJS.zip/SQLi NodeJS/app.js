const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();

// Initialize the database
const db = new sqlite3.Database('demo.db', (err) => {
    if (err) {
        return console.error(err.message);
    }
    console.log('Connected to the SQlite database.');
    
    // Create users table and seed some data
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT
        );
    `, (err) => {
        if (err) {
            console.error(err.message);
        }
        db.run("INSERT OR IGNORE INTO users (username, password) VALUES ('admin', 'password123')");
        db.run("INSERT OR IGNORE INTO users (username, password) VALUES ('bob', 'bobpass')");
        db.run("INSERT OR IGNORE INTO users (username, password) VALUES ('alice', 'alicepass')");
    });
});

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    // Vulnerable SQL statement using string concatenation
    const sql = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
    
    db.get(sql, (err, user) => {
        if (err) {
            return res.send("Error occurred!");
        }
        if (user) {
            res.send('Login successful!');
        } else {
            res.send('Login failed!');
        }
    });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
